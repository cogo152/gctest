#ifndef GCTEST_CORE_TEST_HPP
#define GCTEST_CORE_TEST_HPP

#include <gctest/core/macro.hpp>

#endif